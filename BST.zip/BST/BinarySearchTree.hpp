#include <iostream>
#include "BinarySearchTree.h"
using namespace std;


template <class T>
BST<T>::BST ()
{
    root = NULL;
}    // Queue0

template <class T>
BST<T>::~BST ()
{
    reclaimAllNodes(root);
}

template <class T>
void BST<T>::transferFrom (BST& source)
{
    reclaimAllNodes(root);
    root = source.root;
    source.root = NULL;
} // transferFrom

template <class T>
BST<T>& BST<T>::operator=(BST& rhs)
{
    reclaimAllNodes(root);
    root=rhs.root;
    return *this;
}    // operator =

template <class T>
void BST<T>::clear (void)
{
    reclaimAllNodes(root);
    root = NULL;
} // clear

template <class T>
void BST<T>::reclaimAllNodes (TreeNodeRecord<T>*& root)
// requires: Null(root)  or  Alive(root)
//  ensures: all nodes in BST
//           beginning with root are reclaimed
{
    if (root != NULL) {
        reclaimAllNodes(root->left);
        reclaimAllNodes(root->right);
        root->parent = NULL;
        delete (root);
    } // end if
} // reclaimAllNodes

//----------------------------------------


template <class T>
void BST<T>:: inorederTraversal(){
    inorederTraversal(root);
}

template <class T>
void BST<T>:: inorederTraversal(TreeNodeRecord<T>*& root){
    if(root!=NULL){
        inorederTraversal(root->left);
        cout<<root->value<<", ";
        inorederTraversal(root->right);
    }
}

// This is the public interface of the insert
// Client (main) has no access to root
template <class T>
void BST<T>::insertElement(T& x) {
     root = insertElement(x, root);
}

//private insert function that has access to root.
//recursive implementation
template <class T>
TreeNodeRecord<T>* BST<T>::insertElement(T& x, TreeNodeRecord<T>*& root) {
     TreeNodeRecord<T>* n = new TreeNodeRecord<T>;
     n->parent = NULL;
     n->left = NULL;
     n->right = NULL;

     if (root == NULL) {
          n->value = x;
          return n;
     }
     else if (x < root->value) {
          root->left = insertElement(x, root->left);
          root->left->parent = root;
     }
     else {
          root->right = insertElement(x, root->right);
          root->right->parent = root;
     }
     return root;
}//insert
